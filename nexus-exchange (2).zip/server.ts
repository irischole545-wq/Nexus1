import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, "database.sqlite");
const db = new Database(dbPath);

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS wallets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    currency TEXT NOT NULL,
    balance REAL DEFAULT 0,
    mining_balance REAL DEFAULT 0,
    mining_profit REAL DEFAULT 0,
    last_mining_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    pair TEXT NOT NULL,
    side TEXT NOT NULL, -- 'buy' or 'sell'
    type TEXT NOT NULL, -- 'market' or 'limit'
    price REAL,
    amount REAL NOT NULL,
    filled REAL DEFAULT 0,
    status TEXT DEFAULT 'open', -- 'open', 'filled', 'cancelled'
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pair TEXT NOT NULL,
    price REAL NOT NULL,
    amount REAL NOT NULL,
    side TEXT NOT NULL,
    buyer_id INTEGER,
    seller_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS positions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    pair TEXT NOT NULL,
    side TEXT NOT NULL, -- 'long' or 'short'
    leverage INTEGER NOT NULL,
    entry_price REAL NOT NULL,
    amount REAL NOT NULL,
    liquidation_price REAL NOT NULL,
    status TEXT DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS withdrawals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    currency TEXT NOT NULL,
    amount REAL NOT NULL,
    address TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS support_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    reply TEXT,
    status TEXT DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE INDEX IF NOT EXISTS idx_wallets_user_currency ON wallets(user_id, currency);
  CREATE INDEX IF NOT EXISTS idx_orders_pair_status ON orders(pair, status);
  CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
  CREATE INDEX IF NOT EXISTS idx_trades_pair ON trades(pair);
  CREATE INDEX IF NOT EXISTS idx_positions_user ON positions(user_id);
  CREATE INDEX IF NOT EXISTS idx_withdrawals_user ON withdrawals(user_id);
`);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    },
  });

  const PORT = 3000;
  const JWT_SECRET = process.env.JWT_SECRET || "nexus-secret";

  app.use(express.json());

  // --- Auth Middleware ---
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      req.user = jwt.verify(token, JWT_SECRET);
      next();
    } catch (err) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // --- Trading Engine (Simplified Matching) ---
  const matchOrders = (pair: string) => {
    const buyOrders = db.prepare("SELECT * FROM orders WHERE pair = ? AND side = 'buy' AND status = 'open' ORDER BY price DESC, created_at ASC").all(pair);
    const sellOrders = db.prepare("SELECT * FROM orders WHERE pair = ? AND side = 'sell' AND status = 'open' ORDER BY price ASC, created_at ASC").all(pair);

    for (const buy of buyOrders as any[]) {
      for (const sell of sellOrders as any[]) {
        if (buy.price >= sell.price && buy.status === 'open' && sell.status === 'open') {
          const matchAmount = Math.min(buy.amount - buy.filled, sell.amount - sell.filled);
          const matchPrice = sell.price; // Seller's price for limit orders

          // Update orders
          db.prepare("UPDATE orders SET filled = filled + ?, status = CASE WHEN filled + ? >= amount THEN 'filled' ELSE 'open' END WHERE id = ?")
            .run(matchAmount, matchAmount, buy.id);
          db.prepare("UPDATE orders SET filled = filled + ?, status = CASE WHEN filled + ? >= amount THEN 'filled' ELSE 'open' END WHERE id = ?")
            .run(matchAmount, matchAmount, sell.id);

          // Record trade
          db.prepare("INSERT INTO trades (pair, price, amount, side, buyer_id, seller_id) VALUES (?, ?, ?, ?, ?, ?)")
            .run(pair, matchPrice, matchAmount, 'buy', buy.user_id, sell.user_id);

          // Update wallets (simplified: assuming USDT quote)
          const baseCurrency = pair.split("/")[0];
          const quoteCurrency = "USDT";

          // Buyer gets base, spent quote
          db.prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?").run(matchAmount, buy.user_id, baseCurrency);
          // Seller gets quote, base already deducted
          db.prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?").run(matchAmount * matchPrice, sell.user_id, quoteCurrency);

          io.emit("trade", { pair, price: matchPrice, amount: matchAmount, side: 'buy', time: new Date() });
        }
      }
    }
  };

  // Run matching engine periodically
  setInterval(() => {
    const pairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT"];
    pairs.forEach(matchOrders);
  }, 2000);

  // --- API Routes ---

  // Auth
  app.post("/api/auth/register", async (req, res) => {
    const { email: rawEmail, password } = req.body;
    const email = rawEmail.toLowerCase().trim();
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const result = db.prepare("INSERT INTO users (email, password) VALUES (?, ?)").run(email, hashedPassword);
      const userId = result.lastInsertRowid;
      
      // Initialize wallets
      const currencies = ["USDT", "BTC", "ETH", "SOL"];
      const stmt = db.prepare("INSERT INTO wallets (user_id, currency, balance) VALUES (?, ?, ?)");
      currencies.forEach(curr => stmt.run(userId, curr, 0));

      const token = jwt.sign({ id: userId, email, role: 'user' }, JWT_SECRET);
      res.json({ token, user: { id: userId, email, role: 'user' } });
    } catch (err: any) {
      console.error("Registration error:", err);
      res.status(400).json({ error: "User already exists or invalid data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email: rawEmail, password } = req.body;
    const email = rawEmail.toLowerCase().trim();
    const user: any = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid email or password" });
    }
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, role: user.role } });
  });

  // User Data
  app.get("/api/user/me", authenticate, (req: any, res) => {
    const user: any = db.prepare("SELECT id, email, role FROM users WHERE id = ?").get(req.user.id);
    const wallets = db.prepare("SELECT currency, balance, mining_balance, mining_profit FROM wallets WHERE user_id = ?").all(req.user.id);
    res.json({ ...user, wallets });
  });

  // Trading
  app.post("/api/trade/order", authenticate, (req: any, res) => {
    const { pair, side, type, price, amount } = req.body;
    const userId = req.user.id;

    // Basic balance check (simplified)
    const quoteCurrency = "USDT";
    const baseCurrency = pair.split("/")[0];
    const currencyNeeded = side === "buy" ? quoteCurrency : baseCurrency;
    const amountNeeded = side === "buy" ? (price * amount) : amount;

    const wallet: any = db.prepare("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?").get(userId, currencyNeeded);
    if (!wallet || wallet.balance < amountNeeded) {
      return res.status(400).json({ error: "Insufficient funds" });
    }

    // Deduct balance
    db.prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?").run(amountNeeded, userId, currencyNeeded);

    // Create order
    const result = db.prepare("INSERT INTO orders (user_id, pair, side, type, price, amount) VALUES (?, ?, ?, ?, ?, ?)")
      .run(userId, pair, side, type, price, amount);

    res.json({ id: result.lastInsertRowid, status: "open" });
  });

  // Wallet Actions
  app.post("/api/wallet/deposit", authenticate, (req: any, res) => {
    const { currency, amount } = req.body;
    const userId = req.user.id;
    
    try {
      db.prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?")
        .run(amount, userId, currency);
      res.json({ success: true, message: `Deposited ${amount} ${currency}` });
    } catch (err) {
      res.status(500).json({ error: "Failed to deposit" });
    }
  });

  app.post("/api/wallet/withdraw", authenticate, (req: any, res) => {
    const { currency, amount, address } = req.body;
    const userId = req.user.id;

    if (!address) return res.status(400).json({ error: "Address is required" });

    const wallet: any = db.prepare("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?").get(userId, currency);
    if (!wallet || wallet.balance < amount) {
      return res.status(400).json({ error: "Insufficient funds" });
    }

    try {
      db.prepare("INSERT INTO withdrawals (user_id, currency, amount, address) VALUES (?, ?, ?, ?)")
        .run(userId, currency, amount, address);
      res.json({ success: true, message: `Withdrawal request for ${amount} ${currency} submitted` });
    } catch (err) {
      res.status(500).json({ error: "Failed to process withdrawal request" });
    }
  });

  app.get("/api/wallet/withdrawals", authenticate, (req: any, res) => {
    const userId = req.user.id;
    const withdrawals = db.prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC").all(userId);
    res.json(withdrawals);
  });

  app.post("/api/mining/start", authenticate, (req: any, res) => {
    const { currency, amount } = req.body;
    const userId = req.user.id;

    const wallet: any = db.prepare("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?").get(userId, currency);
    if (!wallet || wallet.balance < amount) {
      return res.status(400).json({ error: "Insufficient funds" });
    }

    try {
      db.transaction(() => {
        db.prepare("UPDATE wallets SET balance = balance - ?, mining_balance = mining_balance + ?, last_mining_at = CURRENT_TIMESTAMP WHERE user_id = ? AND currency = ?")
          .run(amount, amount, userId, currency);
      })();
      res.json({ success: true, message: `Started mining with ${amount} ${currency}` });
    } catch (err) {
      res.status(500).json({ error: "Failed to start mining" });
    }
  });

  app.post("/api/mining/stop", authenticate, (req: any, res) => {
    const { currency } = req.body;
    const userId = req.user.id;

    const wallet: any = db.prepare("SELECT mining_balance FROM wallets WHERE user_id = ? AND currency = ?").get(userId, currency);
    if (!wallet || wallet.mining_balance <= 0) {
      return res.status(400).json({ error: "No active mining for this currency" });
    }

    try {
      db.transaction(() => {
        db.prepare("UPDATE wallets SET balance = balance + mining_balance, mining_balance = 0 WHERE user_id = ? AND currency = ?")
          .run(userId, currency);
      })();
      res.json({ success: true, message: `Stopped mining and moved ${wallet.mining_balance} ${currency} to balance` });
    } catch (err) {
      res.status(500).json({ error: "Failed to stop mining" });
    }
  });

  // Background Mining Reward Processor (Daily 2%)
  // In a real app, this would be a cron job. Here we check every hour and apply rewards if 24h passed.
  setInterval(() => {
    const activeMining = db.prepare("SELECT * FROM wallets WHERE mining_balance > 0").all() as any[];
    const now = new Date();
    
    activeMining.forEach(wallet => {
      const lastUpdate = new Date(wallet.last_mining_at);
      const diffHours = (now.getTime() - lastUpdate.getTime()) / (1000 * 60 * 60);
      
      if (diffHours >= 24) {
        const reward = wallet.mining_balance * 0.02;
        db.prepare("UPDATE wallets SET balance = balance + ?, mining_profit = mining_profit + ?, last_mining_at = CURRENT_TIMESTAMP WHERE id = ?")
          .run(reward, reward, wallet.id);
        console.log(`Applied 2% mining reward to wallet ${wallet.id}: +${reward} ${wallet.currency}`);
      }
    });
  }, 1000 * 60 * 60); // Check every hour

  // Admin
  app.get("/api/admin/users", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const users = db.prepare("SELECT id, email, role, created_at FROM users").all();
    res.json(users);
  });

  app.get("/api/admin/stats", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
    const tradeCount = db.prepare("SELECT COUNT(*) as count FROM trades").get() as any;
    const volume = db.prepare("SELECT SUM(price * amount) as volume FROM trades").get() as any;
    res.json({ users: userCount.count, trades: tradeCount.count, volume: volume.volume || 0 });
  });

  app.get("/api/admin/withdrawals", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const withdrawals = db.prepare(`
      SELECT w.*, u.email 
      FROM withdrawals w 
      JOIN users u ON w.user_id = u.id 
      ORDER BY w.created_at DESC
    `).all();
    res.json(withdrawals);
  });

  app.post("/api/admin/withdrawals/:id/approve", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const { id } = req.params;
    
    const withdrawal: any = db.prepare("SELECT * FROM withdrawals WHERE id = ?").get(id);
    if (!withdrawal || withdrawal.status !== 'pending') {
      return res.status(400).json({ error: "Invalid withdrawal request" });
    }

    const wallet: any = db.prepare("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?").get(withdrawal.user_id, withdrawal.currency);
    if (!wallet || wallet.balance < withdrawal.amount) {
      return res.status(400).json({ error: "User has insufficient funds for this withdrawal" });
    }

    try {
      db.transaction(() => {
        db.prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?")
          .run(withdrawal.amount, withdrawal.user_id, withdrawal.currency);
        db.prepare("UPDATE withdrawals SET status = 'approved' WHERE id = ?").run(id);
      })();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to approve withdrawal" });
    }
  });

  app.post("/api/admin/withdrawals/:id/reject", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const { id } = req.params;
    const withdrawal: any = db.prepare("SELECT * FROM withdrawals WHERE id = ?").get(id);
    if (withdrawal && withdrawal.status === 'pending') {
      db.prepare("UPDATE withdrawals SET status = 'rejected' WHERE id = ?").run(id);
      res.json({ success: true });
    } else {
      res.status(400).json({ error: "Invalid withdrawal request" });
    }
  });

  app.get("/api/admin/user/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const userId = req.params.id;
    const user = db.prepare("SELECT id, email, role, created_at FROM users WHERE id = ?").get(userId);
    if (!user) return res.status(404).json({ error: "User not found" });
    const wallets = db.prepare("SELECT currency, balance FROM wallets WHERE user_id = ?").all(userId);
    const orders = db.prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 10").all(userId);
    res.json({ ...user, wallets, orders });
  });

  app.post("/api/admin/user/:id/role", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const { role } = req.body;
    db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, req.params.id);
    res.json({ success: true });
  });

  app.post("/api/admin/user/:id/balance", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const { currency, amount } = req.body;
    const userId = req.params.id;
    
    db.transaction(() => {
      const oldWallet = db.prepare("SELECT balance FROM wallets WHERE user_id = ? AND currency = ?").get(userId, currency);
      const oldBalance = oldWallet ? oldWallet.balance : 0;
      const addedAmount = amount - oldBalance;

      db.prepare("UPDATE wallets SET balance = ? WHERE user_id = ? AND currency = ?").run(amount, userId, currency);
      
      if (addedAmount > 0) {
        db.prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)")
          .run(userId, "Funds Deposited", `$${addedAmount.toLocaleString()} deposited in your account.`);
        
        if (addedAmount >= 5000) {
          const bonus = 750;
          db.prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'USDT'")
            .run(bonus, userId);
          db.prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)")
            .run(userId, "Bonus Received", "Congratulations! You have received a $750 bonus.");
        }
      }
    })();
    
    res.json({ success: true });
  });

  app.get("/api/admin/support", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const messages = db.prepare(`
      SELECT s.*, u.email 
      FROM support_messages s 
      JOIN users u ON s.user_id = u.id 
      ORDER BY s.created_at DESC
    `).all();
    res.json(messages);
  });

  app.post("/api/admin/support/:id/reply", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    const { id } = req.params;
    const { reply } = req.body;
    db.prepare("UPDATE support_messages SET reply = ?, status = 'closed' WHERE id = ?").run(reply, id);
    res.json({ success: true });
  });

  app.delete("/api/admin/user/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Forbidden" });
    // Delete wallets and orders first due to FK constraints if any (though SQLite might handle it if ON DELETE CASCADE is set, but let's be safe)
    db.prepare("DELETE FROM wallets WHERE user_id = ?").run(req.params.id);
    db.prepare("DELETE FROM orders WHERE user_id = ?").run(req.params.id);
    db.prepare("DELETE FROM notifications WHERE user_id = ?").run(req.params.id);
    db.prepare("DELETE FROM support_messages WHERE user_id = ?").run(req.params.id);
    db.prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Notifications
  app.get("/api/notifications", authenticate, (req: any, res) => {
    const notifications = db.prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC").all(req.user.id);
    res.json(notifications);
  });

  app.post("/api/notifications/read-all", authenticate, (req: any, res) => {
    db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?").run(req.user.id);
    res.json({ success: true });
  });

  // Support
  app.get("/api/support", authenticate, (req: any, res) => {
    const messages = db.prepare("SELECT * FROM support_messages WHERE user_id = ? ORDER BY created_at DESC").all(req.user.id);
    res.json(messages);
  });

  app.post("/api/support", authenticate, (req: any, res) => {
    const { message } = req.body;
    db.prepare("INSERT INTO support_messages (user_id, message) VALUES (?, ?)")
      .run(req.user.id, message);
    res.json({ success: true });
  });

  // Futures
  app.post("/api/futures/position", authenticate, (req: any, res) => {
    const { pair, side, leverage, amount } = req.body;
    const userId = req.user.id;
    const entryPrice = prices[pair];
    
    // Liquidation price calculation (simplified)
    const maintenanceMargin = 0.05;
    const liqPrice = side === 'long' 
      ? entryPrice * (1 - (1 / leverage) + maintenanceMargin)
      : entryPrice * (1 + (1 / leverage) - maintenanceMargin);

    const result = db.prepare("INSERT INTO positions (user_id, pair, side, leverage, entry_price, amount, liquidation_price) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .run(userId, pair, side, leverage, amount, liqPrice);
    
    res.json({ id: result.lastInsertRowid, entryPrice, liquidationPrice: liqPrice });
  });

  app.get("/api/futures/positions", authenticate, (req: any, res) => {
    const positions = db.prepare("SELECT * FROM positions WHERE user_id = ? AND status = 'open'").all(req.user.id);
    res.json(positions);
  });

  // --- Real-time Price Simulation ---
  const prices: any = {
    "BTC/USDT": 98450.50,
    "ETH/USDT": 2745.20,
    "SOL/USDT": 188.75,
  };

  const fetchRealPrices = async () => {
    try {
      const symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"];
      for (const symbol of symbols) {
        const res = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
        const data: any = await res.json();
        if (data.price) {
          const pair = symbol.replace("USDT", "/USDT");
          prices[pair] = parseFloat(parseFloat(data.price).toFixed(2));
        }
      }
    } catch (err) {
      console.error("Error fetching real prices:", err);
    }
  };

  // Initial fetch
  fetchRealPrices();
  // Fetch every 30 seconds
  setInterval(fetchRealPrices, 30000);

  setInterval(() => {
    for (const pair in prices) {
      const change = (Math.random() - 0.5) * (prices[pair] * 0.0002); // Reduced volatility for more realism
      prices[pair] = parseFloat((prices[pair] + change).toFixed(2));
    }
    io.emit("prices", prices);
  }, 1000);

  // --- Vite Integration ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  // --- Seed Data ---
  const seed = async () => {
    const adminExists = db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
    if (!adminExists) {
      const hashedPassword = await bcrypt.hash("admin123", 10);
      const result = db.prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)").run("admin@nexus.com", hashedPassword, "admin");
      const adminId = result.lastInsertRowid;
      
      const currencies = ["USDT", "BTC", "ETH", "SOL"];
      const stmt = db.prepare("INSERT INTO wallets (user_id, currency, balance) VALUES (?, ?, ?)");
      currencies.forEach(curr => stmt.run(adminId, curr, 1000000));
      console.log("Admin user created: admin@nexus.com / admin123");
    }
  };
  await seed();

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
