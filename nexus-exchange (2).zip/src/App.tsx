import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrendingUp, 
  Wallet, 
  BarChart3, 
  LayoutDashboard, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Shield,
  Zap,
  Globe,
  Copy,
  Check,
  User as UserIcon,
  MessageSquare,
  Bell
} from 'lucide-react';
import { io } from 'socket.io-client';
import { useAuthStore, useMarketStore } from './store';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-md bg-slate-900 border border-white/10 rounded-[2rem] shadow-2xl overflow-hidden"
          >
            <div className="p-6 border-b border-white/10 flex items-center justify-between">
              <h3 className="text-xl font-bold text-white">{title}</h3>
              <button onClick={onClose} className="p-2 text-slate-400 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-8">
              {children}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const DepositModal = ({ isOpen, onClose, onDeposit }: { isOpen: boolean, onClose: () => void, onDeposit: () => void }) => {
  const { token } = useAuthStore();
  const [amount, setAmount] = useState('');
  const [currency] = useState('BTC');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const btcAddress = "bc1qm64qljmmhew9ycaptn8vtyrclu4djfde2gt3ag";

  const handleCopy = () => {
    navigator.clipboard.writeText(btcAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDeposit = async () => {
    setLoading(true);
    const res = await fetch('/api/wallet/deposit', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ currency, amount: parseFloat(amount) })
    });
    setLoading(false);
    if (res.ok) {
      onDeposit();
      onClose();
    } else {
      const data = await res.json();
      alert(data.error);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Deposit Assets">
      <div className="space-y-6">
        <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl text-center">
          <p className="text-emerald-400 text-sm font-bold">
            (Deposit $5000 and get $750 bonus instantly)
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Currency</label>
          <div className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white font-bold flex items-center justify-between">
            <span>Bitcoin (BTC)</span>
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
          </div>
        </div>

        <div className="p-4 bg-blue-600/10 border border-blue-500/20 rounded-2xl">
          <label className="block text-xs font-bold text-blue-400 uppercase mb-2">BTC Deposit Address</label>
          <div className="flex items-center gap-3">
            <code className="flex-1 text-xs text-slate-300 break-all bg-slate-950 p-2 rounded-lg border border-white/5 font-mono">
              {btcAddress}
            </code>
            <button 
              onClick={handleCopy}
              className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-all shadow-lg shadow-blue-600/20"
              title="Copy Address"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-[10px] text-slate-500 mt-2">
            * Send only BTC to this address. Sending other assets may result in permanent loss.
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Amount</label>
          <input 
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all"
            placeholder="0.00"
          />
        </div>
        <button 
          onClick={handleDeposit}
          disabled={loading || !amount}
          className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-600/20"
        >
          {loading ? 'Processing...' : 'Confirm Deposit'}
        </button>
      </div>
    </Modal>
  );
};

const WithdrawModal = ({ isOpen, onClose, onWithdraw }: { isOpen: boolean, onClose: () => void, onWithdraw: () => void }) => {
  const { token } = useAuthStore();
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USDT');
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<any[]>([]);

  const fetchHistory = async () => {
    const res = await fetch('/api/wallet/withdrawals', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setHistory(data);
  };

  useEffect(() => {
    if (isOpen && showHistory) {
      fetchHistory();
    }
  }, [isOpen, showHistory]);

  const handleWithdraw = async () => {
    if (!address) {
      alert('Please enter a destination address');
      return;
    }
    setLoading(true);
    const res = await fetch('/api/wallet/withdraw', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ currency, amount: parseFloat(amount), address })
    });
    setLoading(false);
    if (res.ok) {
      onWithdraw();
      onClose();
      alert('Withdrawal request submitted successfully');
    } else {
      const data = await res.json();
      alert(data.error);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={showHistory ? "Withdrawal History" : "Withdraw Assets"}>
      <div className="space-y-6">
        <div className="flex justify-end">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className="text-sm font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            {showHistory ? "Back to Withdraw" : "Withdraw History"}
          </button>
        </div>

        {!showHistory ? (
          <>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Select Currency</label>
              <select 
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all"
              >
                <option value="USDT">USDT</option>
                <option value="BTC">BTC</option>
                <option value="ETH">ETH</option>
                <option value="SOL">SOL</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Destination Address</label>
              <input 
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all font-mono text-sm"
                placeholder="Enter BTC/Wallet address"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Amount</label>
              <input 
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all"
                placeholder="0.00"
              />
            </div>
            <button 
              onClick={handleWithdraw}
              disabled={loading || !amount || !address}
              className="w-full py-4 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg shadow-rose-600/20"
            >
              {loading ? 'Processing...' : 'Confirm Withdrawal'}
            </button>
          </>
        ) : (
          <div className="max-h-[60vh] overflow-y-auto space-y-3">
            {history.length === 0 ? (
              <div className="text-center py-8 text-slate-500">No withdrawal history found</div>
            ) : (
              history.map((w: any) => (
                <div key={w.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl">
                  <div className="flex justify-between items-center">
                    <div className="font-bold text-white">{w.amount} {w.currency}</div>
                    <div className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                      w.status === 'approved' ? "bg-emerald-500/10 text-emerald-500" :
                      w.status === 'rejected' ? "bg-rose-500/10 text-rose-500" :
                      "bg-amber-500/10 text-amber-500"
                    )}>
                      {w.status}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </Modal>
  );
};

const MiningModal = ({ isOpen, onClose, onMining, userData }: { isOpen: boolean, onClose: () => void, onMining: () => void, userData: any }) => {
  const { token } = useAuthStore();
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USDT');
  const [loading, setLoading] = useState(false);

  const handleStartMining = async () => {
    const miningAmount = parseFloat(amount);
    const activeWallet = userData?.wallets?.find((w: any) => w.currency === currency);
    
    if (miningAmount > (activeWallet?.balance || 0)) {
      alert('Insufficient funds');
      return;
    }

    setLoading(true);
    const res = await fetch('/api/mining/start', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ currency, amount: parseFloat(amount) })
    });
    setLoading(false);
    if (res.ok) {
      onMining();
      onClose();
      alert('Mining session started! You will earn 2% daily.');
    } else {
      const data = await res.json();
      alert(data.error);
    }
  };

  const activeWallet = userData?.wallets?.find((w: any) => w.currency === currency);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Start Cloud Mining">
      <div className="space-y-6">
        <div className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl">
          <div className="flex items-center gap-3 mb-2">
            <Zap className="text-amber-500 w-5 h-5" />
            <span className="text-amber-500 font-bold">Daily Yield: 2.00%</span>
          </div>
          <p className="text-xs text-slate-400">
            Your assets will be locked in the mining pool and generate daily rewards. You can stop mining anytime to return assets to your wallet.
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">Select Asset</label>
          <select 
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all"
          >
            <option value="USDT">USDT</option>
            <option value="BTC">BTC</option>
            <option value="ETH">ETH</option>
            <option value="SOL">SOL</option>
          </select>
        </div>

        <div>
          <div className="flex justify-between mb-2">
            <label className="text-sm font-medium text-slate-400">Amount to Mine</label>
            <span className="text-xs text-slate-500">Available: {activeWallet?.balance.toLocaleString()} {currency}</span>
          </div>
          <div className="relative">
            <input 
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all"
              placeholder="0.00"
            />
            <button 
              onClick={() => setAmount(activeWallet?.balance.toString() || '0')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-blue-500 hover:text-blue-400"
            >
              MAX
            </button>
          </div>
        </div>

        <button 
          onClick={handleStartMining}
          disabled={loading || !amount || parseFloat(amount) <= 0}
          className="w-full py-4 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg shadow-amber-600/20"
        >
          {loading ? 'Initializing...' : 'Start Mining Now'}
        </button>
      </div>
    </Modal>
  );
};

const Navbar = () => {
  const { user, logout } = useAuthStore();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
      isScrolled ? "bg-slate-950/80 backdrop-blur-md border-white/10 py-3" : "bg-transparent border-transparent py-5"
    )}>
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:scale-110 transition-transform">
            <TrendingUp className="text-white w-6 h-6" />
          </div>
          <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
            NEXUS
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link to="/market" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Market</Link>
          <Link to="/trade" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Trade</Link>
          <Link to="/futures" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Futures</Link>
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-4">
              {user.role === 'admin' && (
                <Link to="/admin" className="text-sm font-bold text-purple-400 hover:text-purple-300 transition-colors">Admin</Link>
              )}
              <Link to="/dashboard" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Dashboard</Link>
              <button onClick={logout} className="p-2 text-slate-400 hover:text-white transition-colors">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Login</Link>
              <Link to="/register" className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold rounded-lg transition-all shadow-lg shadow-blue-600/20">
                Get Started
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

// --- Pages ---

const LandingPage = () => {
  const { prices } = useMarketStore();
  
  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/20 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/20 blur-[120px] rounded-full" />
        </div>

        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-xs font-bold tracking-widest uppercase bg-white/5 border border-white/10 rounded-full text-blue-400">
              The Future of Trading is Here
            </span>
            <h1 className="text-5xl md:text-7xl font-extrabold mb-8 leading-tight">
              Trade Crypto with <br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">
                Institutional Precision
              </span>
            </h1>
            <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10">
              Experience the world's most advanced cryptocurrency exchange. 
              Ultra-low latency, deep liquidity, and military-grade security.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/register" className="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-2 group">
                Start Trading Now
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/market" className="w-full sm:w-auto px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl font-bold text-lg transition-all">
                View Markets
              </Link>
            </div>
          </motion.div>

          {/* Live Ticker */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-20 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto"
          >
            {Object.entries(prices).map(([pair, price]) => (
              <div key={pair} className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm hover:border-blue-500/50 transition-colors group">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 font-medium">{pair.split('/')[0]}</span>
                  <div className="p-1.5 bg-emerald-500/10 rounded-lg">
                    <ArrowUpRight className="w-4 h-4 text-emerald-500" />
                  </div>
                </div>
                <div className="text-2xl font-bold group-hover:text-blue-400 transition-colors">
                  ${(price || 0).toLocaleString()}
                </div>
                <div className="text-xs text-emerald-500 font-medium mt-1">+2.45%</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Nexus?</h2>
            <p className="text-slate-400">Engineered for the most demanding traders.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Zap, title: "Lightning Fast", desc: "Our matching engine handles 1M+ transactions per second with sub-millisecond latency." },
              { icon: Shield, title: "Bank-Grade Security", desc: "Multi-sig cold storage and real-time threat detection keep your assets safe." },
              { icon: Globe, title: "Global Liquidity", desc: "Access deep liquidity pools across major global exchanges for the best spreads." }
            ].map((feature, i) => (
              <div key={i} className="p-8 bg-slate-950 border border-white/5 rounded-3xl hover:border-blue-500/30 transition-all">
                <div className="w-14 h-14 bg-blue-600/10 rounded-2xl flex items-center justify-center mb-6">
                  <feature.icon className="w-7 h-7 text-blue-500" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-slate-400 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email.trim(), password })
    });
    const data = await res.json();
    if (res.ok) {
      setAuth(data.user, data.token);
      navigate('/dashboard');
    } else {
      alert(data.error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
              <TrendingUp className="text-white w-7 h-7" />
            </div>
          </Link>
          <h1 className="text-3xl font-bold text-white">Welcome Back</h1>
          <p className="text-slate-400 mt-2">Enter your credentials to access your account</p>
        </div>

        <div className="bg-slate-900 border border-white/10 p-8 rounded-3xl backdrop-blur-xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Email Address</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                placeholder="name@example.com"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                placeholder="••••••••"
                required
              />
            </div>
            <button type="submit" className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-600/20">
              Sign In
            </button>
          </form>
          <p className="text-center text-slate-400 mt-6 text-sm">
            Don't have an account? <Link to="/register" className="text-blue-400 hover:underline">Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

const RegisterPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email.trim(), password })
    });
    const data = await res.json();
    if (res.ok) {
      setAuth(data.user, data.token);
      navigate('/dashboard');
    } else {
      alert(data.error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center">
              <TrendingUp className="text-white w-7 h-7" />
            </div>
          </Link>
          <h1 className="text-3xl font-bold text-white">Create Account</h1>
          <p className="text-slate-400 mt-2">Join 1M+ traders worldwide</p>
        </div>

        <div className="bg-slate-900 border border-white/10 p-8 rounded-3xl backdrop-blur-xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Email Address</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                placeholder="name@example.com"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                placeholder="••••••••"
                required
              />
            </div>
            <button type="submit" className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-600/20">
              Create Account
            </button>
          </form>
          <p className="text-center text-slate-400 mt-6 text-sm">
            Already have an account? <Link to="/login" className="text-blue-400 hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

const Dashboard = () => {
  const { user, token, logout } = useAuthStore();
  const { prices } = useMarketStore();
  const [userData, setUserData] = useState<any>(null);
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isMiningOpen, setIsMiningOpen] = useState(false);

  const navigate = useNavigate();

  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      const res = await fetch('/api/user/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) {
        if (res.status === 401) {
          logout();
          navigate('/login');
          return;
        }
        throw new Error('Failed to fetch user data');
      }
      const data = await res.json();
      setUserData(data);
    } catch (err) {
      console.error(err);
      setError('Failed to load dashboard data. Please try again.');
    }
  };

  useEffect(() => {
    if (!token) {
      navigate('/login');
    } else {
      fetchData();
    }
  }, [token]);

  if (error) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white p-4">
        <div className="bg-slate-900 border border-white/10 p-8 rounded-[2rem] max-w-md w-full text-center">
          <div className="w-16 h-16 bg-rose-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <X className="text-rose-500 w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold mb-4">Connection Error</h2>
          <p className="text-slate-400 mb-8">{error}</p>
          <button 
            onClick={() => { setError(null); fetchData(); }}
            className="w-full py-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all"
          >
            Retry Connection
          </button>
        </div>
      </div>
    );
  }

  if (!userData) return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white">
    <div className="flex flex-col items-center gap-4">
      <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      <p className="text-slate-400 font-medium">Loading your dashboard...</p>
    </div>
  </div>;

  const totalBalance = userData.wallets.reduce((acc: number, w: any) => {
    const balance = (w.balance || 0) + (w.mining_balance || 0);
    if (w.currency === 'USDT') return acc + balance;
    const price = prices[`${w.currency}/USDT`] || 0;
    return acc + (balance * price);
  }, 0);

  const totalMiningBalance = userData.wallets.reduce((acc: number, w: any) => {
    const mBalance = w.mining_balance || 0;
    if (w.currency === 'USDT') return acc + mBalance;
    const price = prices[`${w.currency}/USDT`] || 0;
    return acc + (mBalance * price);
  }, 0);

  const totalProfitUSD = userData.wallets.reduce((acc: number, w: any) => {
    const profit = w.mining_profit || 0;
    if (w.currency === 'USDT') return acc + profit;
    const price = prices[`${w.currency}/USDT`] || 0;
    return acc + (profit * price);
  }, 0);

  const initialBalance = totalBalance - totalProfitUSD;
  const profitPercentage = initialBalance > 0 ? (totalProfitUSD / initialBalance) * 100 : 0;

  return (
    <div className="min-h-screen bg-slate-950 pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-10">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Welcome back, {userData.email.split('@')[0]}</h1>
          </div>
          <div className="flex flex-col items-stretch md:items-end gap-3">
            <div className="flex gap-3">
              <button 
                onClick={() => setIsDepositOpen(true)}
                className="flex-1 md:flex-none px-12 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl transition-all"
              >
                Deposit
              </button>
              <button 
                onClick={() => setIsWithdrawOpen(true)}
                className="flex-1 md:flex-none px-12 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-semibold rounded-xl transition-all"
              >
                Withdraw
              </button>
            </div>
            <button 
              onClick={() => setIsMiningOpen(true)}
              className="w-full md:w-auto px-12 py-2.5 bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/30 text-amber-500 font-bold rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              Start Mining
            </button>
          </div>
        </div>

        <DepositModal 
          isOpen={isDepositOpen} 
          onClose={() => setIsDepositOpen(false)} 
          onDeposit={fetchData} 
        />
        <WithdrawModal 
          isOpen={isWithdrawOpen} 
          onClose={() => setIsWithdrawOpen(false)} 
          onWithdraw={fetchData} 
        />
        <MiningModal 
          isOpen={isMiningOpen} 
          onClose={() => setIsMiningOpen(false)} 
          onMining={fetchData} 
          userData={userData}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
          {/* Main Balance Card */}
          <div className="lg:col-span-2 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[2rem] p-8 relative overflow-hidden shadow-2xl shadow-blue-600/20">
            <div className="absolute top-0 right-0 p-8 opacity-20">
              <Wallet className="w-32 h-32" />
            </div>
            <div className="relative z-10">
              <span className="text-blue-100/80 font-medium uppercase tracking-wider text-sm">Total Estimated Balance</span>
              <div className="flex items-baseline gap-3 mt-2">
                <h2 className="text-5xl font-extrabold text-white">${(totalBalance || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h2>
                <div className="flex flex-col">
                  <span className="text-blue-200 font-medium">USD</span>
                  <span className="text-emerald-300 text-xs font-bold">+2% Daily</span>
                </div>
              </div>
              <div className="flex items-center gap-6 mt-6">
                {totalProfitUSD > 0 && (
                  <div className="flex items-center gap-2 text-emerald-300 font-semibold bg-emerald-500/20 w-fit px-3 py-1 rounded-full text-sm">
                    <ArrowUpRight className="w-4 h-4" />
                    +{profitPercentage.toFixed(2)}% (${totalProfitUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })})
                  </div>
                )}
                {totalMiningBalance > 0 && (
                  <div className="flex items-center gap-2 text-amber-300 font-semibold bg-amber-500/20 w-fit px-3 py-1 rounded-full text-sm animate-pulse">
                    <Zap className="w-4 h-4" />
                    Mining: ${totalMiningBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Market Quick View */}
          <div className="bg-slate-900 border border-white/10 rounded-[2rem] p-8">
            <h3 className="text-xl font-bold text-white mb-6">Market Trends</h3>
            <div className="space-y-6">
              {Object.entries(prices).map(([pair, price]) => (
                <div key={pair} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center">
                      <Zap className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <div className="font-bold text-white">{pair.split('/')[0]}</div>
                      <div className="text-xs text-slate-500">Vol: $1.2B</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-white">${(price || 0).toLocaleString()}</div>
                    <div className="text-xs text-emerald-500">+1.2%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Asset List */}
        <div className="bg-slate-900 border border-white/10 rounded-[2rem] overflow-hidden">
          <div className="p-8 border-b border-white/10 flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">Your Assets</h3>
            <Link to="/wallet" className="text-sm text-blue-400 hover:underline">View All Wallets</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-500 text-sm uppercase tracking-wider">
                  <th className="px-8 py-4 font-medium">Asset</th>
                  <th className="px-8 py-4 font-medium">Balance</th>
                  <th className="px-8 py-4 font-medium">Value (USD)</th>
                  <th className="px-8 py-4 font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {userData.wallets.map((w: any) => {
                  const price = w.currency === 'USDT' ? 1 : (prices[`${w.currency}/USDT`] || 0);
                  const totalAssetBalance = (w.balance || 0) + (w.mining_balance || 0);
                  const value = totalAssetBalance * price;
                  return (
                    <tr key={w.currency} className="hover:bg-white/5 transition-colors group">
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center group-hover:bg-blue-600/20 transition-colors">
                            <span className="font-bold text-blue-400">{w.currency[0]}</span>
                          </div>
                          <span className="font-bold text-white">{w.currency}</span>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="font-medium text-white">{(w.balance || 0).toLocaleString()} {w.currency}</div>
                        {w.mining_balance > 0 && (
                          <div className="text-[10px] text-amber-500 flex items-center gap-1 mt-1">
                            <Zap className="w-2 h-2" />
                            Mining: {w.mining_balance.toLocaleString()}
                          </div>
                        )}
                      </td>
                      <td className="px-8 py-6">
                        <div className="font-medium text-white">${(value || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                      </td>
                      <td className="px-8 py-6">
                        <Link to="/trade" className="text-sm font-bold text-blue-400 hover:text-blue-300">Trade</Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

const TradePage = () => {
  const { prices } = useMarketStore();
  const { token } = useAuthStore();
  const [selectedPair, setSelectedPair] = useState('BTC/USDT');
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');

  const handleOrder = async () => {
    const res = await fetch('/api/trade/order', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        pair: selectedPair,
        side,
        type: 'limit',
        price: parseFloat(price || prices[selectedPair].toString()),
        amount: parseFloat(amount)
      })
    });
    const data = await res.json();
    if (res.ok) {
      alert('Order placed successfully!');
    } else {
      alert(data.error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 pt-20 flex flex-col">
      {/* Trading Header */}
      <div className="bg-slate-900 border-b border-white/10 px-4 py-3 flex items-center gap-8">
        <div className="flex items-center gap-4">
          <select 
            value={selectedPair} 
            onChange={(e) => setSelectedPair(e.target.value)}
            className="bg-transparent text-white font-bold text-xl outline-none cursor-pointer"
          >
            {Object.keys(prices).map(p => <option key={p} value={p} className="bg-slate-900">{p}</option>)}
          </select>
          <div className="text-2xl font-mono font-bold text-emerald-500">
            ${prices[selectedPair]?.toLocaleString()}
          </div>
        </div>
        <div className="hidden md:flex items-center gap-6 text-sm">
          <div>
            <div className="text-slate-500">24h Change</div>
            <div className="text-emerald-500 font-medium">+4.52%</div>
          </div>
          <div>
            <div className="text-slate-500">24h High</div>
            <div className="text-white font-medium">${((prices[selectedPair] || 0) * 1.02).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
          <div>
            <div className="text-slate-500">24h Low</div>
            <div className="text-white font-medium">${((prices[selectedPair] || 0) * 0.97).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
          </div>
          <div>
            <div className="text-slate-500">24h Volume</div>
            <div className="text-white font-medium">{(12450).toLocaleString()} {selectedPair.split('/')[0]}</div>
          </div>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 overflow-hidden">
        {/* Chart Area */}
        <div className="lg:col-span-3 bg-slate-950 border-r border-white/10 flex flex-col">
          <div className="flex-1 flex items-center justify-center text-slate-600 font-medium italic">
            <div className="text-center">
              <BarChart3 className="w-16 h-16 mx-auto mb-4 opacity-20" />
              Interactive TradingView Chart Integration
              <div className="text-xs mt-2 opacity-50">Real-time data streaming active</div>
            </div>
          </div>
          
          {/* Order Book (Simplified) */}
          <div className="h-64 bg-slate-900 border-t border-white/10 grid grid-cols-2">
            <div className="p-4 border-r border-white/10">
              <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Asks (Sell)</h4>
              <div className="space-y-1">
                {[1,2,3,4,5].map(i => (
                  <div key={i} className="flex justify-between text-xs">
                    <span className="text-rose-500 font-mono">{(prices[selectedPair] + i * 10).toFixed(2)}</span>
                    <span className="text-slate-400">0.{i}42</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-4">
              <h4 className="text-xs font-bold text-slate-500 uppercase mb-3">Bids (Buy)</h4>
              <div className="space-y-1">
                {[1,2,3,4,5].map(i => (
                  <div key={i} className="flex justify-between text-xs">
                    <span className="text-emerald-500 font-mono">{(prices[selectedPair] - i * 10).toFixed(2)}</span>
                    <span className="text-slate-400">1.{i}21</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Trade Panel */}
        <div className="bg-slate-900 p-6 flex flex-col gap-6">
          <div className="flex bg-slate-950 p-1 rounded-xl">
            <button 
              onClick={() => setSide('buy')}
              className={cn(
                "flex-1 py-2.5 rounded-lg font-bold transition-all",
                side === 'buy' ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/20" : "text-slate-500 hover:text-white"
              )}
            >
              Buy
            </button>
            <button 
              onClick={() => setSide('sell')}
              className={cn(
                "flex-1 py-2.5 rounded-lg font-bold transition-all",
                side === 'sell' ? "bg-rose-600 text-white shadow-lg shadow-rose-600/20" : "text-slate-500 hover:text-white"
              )}
            >
              Sell
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Price (USDT)</label>
              <div className="relative">
                <input 
                  type="number" 
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder={prices[selectedPair]?.toString()}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all font-mono"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Amount ({selectedPair.split('/')[0]})</label>
              <input 
                type="number" 
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all font-mono"
                placeholder="0.00"
              />
            </div>
            
            <div className="pt-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-500">Total</span>
                <span className="text-white font-bold">{(parseFloat(amount || '0') * (parseFloat(price) || prices[selectedPair] || 0)).toFixed(2)} USDT</span>
              </div>
              <button 
                onClick={handleOrder}
                className={cn(
                  "w-full py-4 rounded-xl font-bold text-white transition-all shadow-lg",
                  side === 'buy' ? "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20" : "bg-rose-600 hover:bg-rose-500 shadow-rose-600/20"
                )}
              >
                {side === 'buy' ? 'Buy' : 'Sell'} {selectedPair.split('/')[0]}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const FuturesPage = () => {
  const { prices } = useMarketStore();
  const { token } = useAuthStore();
  const [selectedPair, setSelectedPair] = useState('BTC/USDT');
  const [side, setSide] = useState<'long' | 'short'>('long');
  const [leverage, setLeverage] = useState(10);
  const [amount, setAmount] = useState('');
  const [positions, setPositions] = useState<any[]>([]);

  const fetchPositions = async () => {
    const res = await fetch('/api/futures/positions', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setPositions(data);
  };

  useEffect(() => {
    if (token) fetchPositions();
  }, [token]);

  const handleOpenPosition = async () => {
    const res = await fetch('/api/futures/position', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        pair: selectedPair,
        side,
        leverage,
        amount: parseFloat(amount)
      })
    });
    if (res.ok) {
      alert('Position opened!');
      fetchPositions();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 pt-20 flex flex-col">
      <div className="bg-slate-900 border-b border-white/10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <h2 className="text-xl font-bold text-white">Perpetual Futures</h2>
          <select 
            value={selectedPair} 
            onChange={(e) => setSelectedPair(e.target.value)}
            className="bg-transparent text-blue-400 font-bold outline-none"
          >
            {Object.keys(prices).map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          <div className="text-xl font-mono text-emerald-500">${prices[selectedPair]?.toLocaleString()}</div>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4">
        <div className="lg:col-span-3 p-6 flex flex-col gap-6">
          <div className="bg-slate-900 border border-white/10 rounded-3xl p-6">
            <h3 className="text-lg font-bold text-white mb-6">Open Positions</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-slate-500 text-xs uppercase">
                    <th className="pb-4">Pair</th>
                    <th className="pb-4">Side</th>
                    <th className="pb-4">Leverage</th>
                    <th className="pb-4">Entry Price</th>
                    <th className="pb-4">Liq. Price</th>
                    <th className="pb-4">PnL</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {positions.map((pos: any) => {
                    const currentPrice = prices[pos.pair] || pos.entry_price;
                    const pnl = pos.side === 'long' 
                      ? (currentPrice - pos.entry_price) * pos.amount * pos.leverage
                      : (pos.entry_price - currentPrice) * pos.amount * pos.leverage;
                    return (
                      <tr key={pos.id} className="border-t border-white/5">
                        <td className="py-4 font-bold text-white">{pos.pair}</td>
                        <td className="py-4">
                          <span className={cn("px-2 py-0.5 rounded text-xs font-bold", pos.side === 'long' ? "bg-emerald-500/10 text-emerald-500" : "bg-rose-500/10 text-rose-500")}>
                            {pos.side.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-4 text-white">{pos.leverage}x</td>
                        <td className="py-4 font-mono text-white">${(pos.entry_price || 0).toLocaleString()}</td>
                        <td className="py-4 font-mono text-rose-400">${(pos.liquidation_price || 0).toLocaleString()}</td>
                        <td className={cn("py-4 font-bold", pnl >= 0 ? "text-emerald-500" : "text-rose-500")}>
                          ${(pnl || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-6 border-l border-white/10 flex flex-col gap-6">
          <div className="flex bg-slate-950 p-1 rounded-xl">
            <button onClick={() => setSide('long')} className={cn("flex-1 py-2 rounded-lg font-bold", side === 'long' ? "bg-emerald-600 text-white" : "text-slate-500")}>Long</button>
            <button onClick={() => setSide('short')} className={cn("flex-1 py-2 rounded-lg font-bold", side === 'short' ? "bg-rose-600 text-white" : "text-slate-500")}>Short</button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Leverage: {leverage}x</label>
              <input 
                type="range" min="1" max="50" value={leverage} 
                onChange={(e) => setLeverage(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Margin (USDT)</label>
              <input 
                type="number" value={amount} onChange={(e) => setAmount(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none"
                placeholder="0.00"
              />
            </div>
            <div className="p-4 bg-slate-950 rounded-2xl border border-white/5 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Position Size</span>
                <span className="text-white font-bold">${((parseFloat(amount || '0') * leverage) || 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Est. Liq Price</span>
                <span className="text-rose-400 font-bold">
                  ${((prices[selectedPair] * (side === 'long' ? (1 - 1/leverage + 0.05) : (1 + 1/leverage - 0.05))) || 0).toLocaleString()}
                </span>
              </div>
            </div>
            <button 
              onClick={handleOpenPosition}
              className={cn("w-full py-4 rounded-xl font-bold text-white shadow-lg", side === 'long' ? "bg-emerald-600 shadow-emerald-600/20" : "bg-rose-600 shadow-rose-600/20")}
            >
              Open {side.toUpperCase()}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const WalletPage = () => {
  const { token, logout } = useAuthStore();
  const { prices } = useMarketStore();
  const [userData, setUserData] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      navigate('/login');
      return;
    }
    fetch('/api/user/me', { headers: { 'Authorization': `Bearer ${token}` } })
      .then(res => {
        if (!res.ok) {
          if (res.status === 401) {
            logout();
            navigate('/login');
          }
          throw new Error('Unauthorized');
        }
        return res.json();
      })
      .then(setUserData)
      .catch(console.error);
  }, [token]);

  if (!userData) return <div className="min-h-screen bg-slate-950 flex items-center justify-center">
    <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
  </div>;

  return (
    <div className="min-h-screen bg-slate-950 pt-24 px-4">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8">My Wallets</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {userData.wallets.map((w: any) => (
            <div key={w.currency} className="bg-slate-900 border border-white/10 p-6 rounded-3xl hover:border-blue-500/50 transition-all group">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-600/10 rounded-2xl flex items-center justify-center group-hover:bg-blue-600 transition-all">
                  <span className="text-xl font-bold text-blue-400 group-hover:text-white">{w.currency[0]}</span>
                </div>
                <div className="text-right">
                  <div className="text-slate-500 text-xs uppercase font-bold">Balance</div>
                  <div className="text-xl font-bold text-white">{(w.balance || 0).toLocaleString()} {w.currency}</div>
                </div>
              </div>
              <div className="pt-4 border-t border-white/5 flex justify-between items-center">
                <span className="text-slate-400 text-sm">≈ ${((w.balance * (w.currency === 'USDT' ? 1 : (prices[`${w.currency}/USDT`] || 0))) || 0).toLocaleString()} USD</span>
                <button className="text-blue-400 font-bold text-sm hover:underline">History</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const ProfileModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const { user, logout } = useAuthStore();
  if (!user) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="My Profile">
      <div className="p-8">
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 bg-blue-600/20 rounded-full flex items-center justify-center mb-4">
            <UserIcon className="w-10 h-10 text-blue-500" />
          </div>
          <h3 className="text-xl font-bold text-white">{user.email.split('@')[0]}</h3>
          <p className="text-slate-400 text-sm">{user.email}</p>
          <div className="mt-2 px-3 py-1 bg-blue-600/10 text-blue-400 text-[10px] font-bold uppercase tracking-wider rounded-full">
            {user.role} Account
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
            <div className="text-xs text-slate-500 uppercase font-bold mb-1">Account ID</div>
            <div className="text-white font-mono">#NX-{user.id.toString().padStart(6, '0')}</div>
          </div>
          <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
            <div className="text-xs text-slate-500 uppercase font-bold mb-1">Joined Date</div>
            <div className="text-white">{new Date(user.created_at).toLocaleDateString()}</div>
          </div>
        </div>

        <button 
          onClick={() => { logout(); onClose(); }}
          className="w-full mt-8 py-4 bg-rose-600/10 hover:bg-rose-600/20 text-rose-500 font-bold rounded-xl transition-all flex items-center justify-center gap-2"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </Modal>
  );
};

const NotificationModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const { token } = useAuthStore();
  const [notifications, setNotifications] = useState<any[]>([]);

  const fetchNotifications = async () => {
    if (!token) return;
    const res = await fetch('/api/notifications', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setNotifications(data);
    
    // Mark all as read when opening
    await fetch('/api/notifications/read-all', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
  };

  useEffect(() => {
    if (isOpen) fetchNotifications();
  }, [isOpen]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Notifications">
      <div className="max-h-[60vh] overflow-y-auto p-4 space-y-3">
        {notifications.length === 0 ? (
          <div className="py-12 text-center text-slate-500">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p>No new notifications</p>
          </div>
        ) : (
          notifications.map((n) => (
            <div key={n.id} className={cn(
              "p-4 rounded-2xl border transition-all",
              n.is_read ? "bg-white/5 border-white/5" : "bg-blue-600/5 border-blue-500/20"
            )}>
              <div className="flex justify-between items-start mb-1">
                <h4 className="font-bold text-white text-sm">{n.title}</h4>
                <span className="text-[10px] text-slate-500">{new Date(n.created_at).toLocaleDateString()}</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">{n.message}</p>
            </div>
          ))
        )}
      </div>
    </Modal>
  );
};

const SupportModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const { token } = useAuthStore();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<any[]>([]);
  const [isSending, setIsSending] = useState(false);

  const fetchMessages = async () => {
    if (!token) return;
    const res = await fetch('/api/support', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setMessages(data);
  };

  useEffect(() => {
    if (isOpen) fetchMessages();
  }, [isOpen]);

  const handleSend = async () => {
    if (!message.trim() || !token) return;
    setIsSending(true);
    await fetch('/api/support', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ message })
    });
    setMessage('');
    fetchMessages();
    setIsSending(false);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Customer Support">
      <div className="flex flex-col h-[60vh]">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 p-8">
              <MessageSquare className="w-12 h-12 mb-4 opacity-20" />
              <p className="font-medium">How can we help you today?</p>
              <p className="text-xs mt-2">Send us a message and our team will get back to you shortly.</p>
            </div>
          ) : (
            messages.map((m) => (
              <div key={m.id} className="space-y-2">
                <div className="flex justify-end">
                  <div className="bg-blue-600 text-white p-3 rounded-2xl rounded-tr-none max-w-[80%] text-sm">
                    {m.message}
                  </div>
                </div>
                {m.reply && (
                  <div className="flex justify-start">
                    <div className="bg-slate-800 text-slate-200 p-3 rounded-2xl rounded-tl-none max-w-[80%] text-sm">
                      {m.reply}
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
        <div className="p-4 border-t border-white/10 bg-slate-900/50">
          <div className="flex gap-2">
            <input 
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your complaint or message..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-white outline-none focus:border-blue-500/50"
            />
            <button 
              onClick={handleSend}
              disabled={isSending}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white p-2 rounded-xl transition-all"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

const BottomNav = ({ 
  onSupport, 
  onTrade, 
  onNotification, 
  onMy 
}: { 
  onSupport: () => void, 
  onTrade: () => void, 
  onNotification: () => void, 
  onMy: () => void 
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-xl border-t border-white/10 px-6 py-3 md:hidden">
      <div className="flex items-center justify-between max-w-md mx-auto">
        <button onClick={onSupport} className="flex flex-col items-center gap-1 text-slate-400 hover:text-blue-400 transition-colors">
          <MessageSquare className="w-6 h-6" />
          <span className="text-[10px] font-medium">Support</span>
        </button>
        <button onClick={onTrade} className="flex flex-col items-center gap-1 text-slate-400 hover:text-blue-400 transition-colors">
          <TrendingUp className="w-6 h-6" />
          <span className="text-[10px] font-medium">Trade</span>
        </button>
        <button onClick={onNotification} className="flex flex-col items-center gap-1 text-slate-400 hover:text-blue-400 transition-colors">
          <Bell className="w-6 h-6" />
          <span className="text-[10px] font-medium">Alerts</span>
        </button>
        <button onClick={onMy} className="flex flex-col items-center gap-1 text-slate-400 hover:text-blue-400 transition-colors">
          <UserIcon className="w-6 h-6" />
          <span className="text-[10px] font-medium">My</span>
        </button>
      </div>
    </div>
  );
};

const AdminPanel = () => {
  const { token, user } = useAuthStore();
  const [users, setUsers] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [supportMessages, setSupportMessages] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isManageOpen, setIsManageOpen] = useState(false);
  const [editBalance, setEditBalance] = useState({ currency: 'USDT', amount: '' });
  const [replyingTo, setReplyingTo] = useState<any>(null);
  const [replyText, setReplyText] = useState('');

  const fetchData = async () => {
    if (token && user?.role === 'admin') {
      const usersRes = await fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${token}` } });
      const usersData = await usersRes.json();
      setUsers(usersData);
      
      const statsRes = await fetch('/api/admin/stats', { headers: { 'Authorization': `Bearer ${token}` } });
      const statsData = await statsRes.json();
      setStats(statsData);
    }
  };

  const fetchWithdrawals = async () => {
    if (token && user?.role === 'admin') {
      const res = await fetch('/api/admin/withdrawals', { headers: { 'Authorization': `Bearer ${token}` } });
      const data = await res.json();
      setWithdrawals(data);
    }
  };

  const fetchSupportMessages = async () => {
    if (token && user?.role === 'admin') {
      const res = await fetch('/api/admin/support', { headers: { 'Authorization': `Bearer ${token}` } });
      const data = await res.json();
      setSupportMessages(data);
    }
  };

  useEffect(() => {
    fetchData();
    fetchWithdrawals();
    fetchSupportMessages();
  }, [token, user]);

  const handleApproveWithdrawal = async (id: number) => {
    await fetch(`/api/admin/withdrawals/${id}/approve`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    fetchWithdrawals();
  };

  const handleRejectWithdrawal = async (id: number) => {
    await fetch(`/api/admin/withdrawals/${id}/reject`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    fetchWithdrawals();
  };

  const handleManageUser = async (userId: number) => {
    const res = await fetch(`/api/admin/user/${userId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    setSelectedUser(data);
    setIsManageOpen(true);
  };

  const handleUpdateRole = async (role: string) => {
    if (!selectedUser) return;
    await fetch(`/api/admin/user/${selectedUser.id}/role`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ role })
    });
    handleManageUser(selectedUser.id);
    fetchData();
  };

  const handleUpdateBalance = async () => {
    if (!selectedUser) return;
    await fetch(`/api/admin/user/${selectedUser.id}/balance`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ 
        currency: editBalance.currency, 
        amount: parseFloat(editBalance.amount) 
      })
    });
    handleManageUser(selectedUser.id);
    setEditBalance({ ...editBalance, amount: '' });
  };

  const handleDeleteUser = async () => {
    if (!selectedUser || !confirm('Are you sure you want to delete this user?')) return;
    await fetch(`/api/admin/user/${selectedUser.id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    setIsManageOpen(false);
    fetchData();
  };

  const handleReplySupport = async () => {
    if (!replyingTo || !replyText) return;
    await fetch(`/api/admin/support/${replyingTo.id}/reply`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ reply: replyText })
    });
    setReplyingTo(null);
    setReplyText('');
    fetchSupportMessages();
  };

  if (user?.role !== 'admin') return <div className="min-h-screen pt-24 text-center text-white">Access Denied</div>;

  return (
    <div className="min-h-screen bg-slate-950 pt-24 px-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-white mb-8">Admin Control Center</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-slate-900 p-8 rounded-3xl border border-white/10">
            <div className="text-slate-500 text-sm font-bold uppercase mb-2">Total Users</div>
            <div className="text-4xl font-extrabold text-white">{stats?.users || 0}</div>
          </div>
          <div className="bg-slate-900 p-8 rounded-3xl border border-white/10">
            <div className="text-slate-500 text-sm font-bold uppercase mb-2">Total Trades</div>
            <div className="text-4xl font-extrabold text-white">{stats?.trades || 0}</div>
          </div>
          <div className="bg-slate-900 p-8 rounded-3xl border border-white/10">
            <div className="text-slate-500 text-sm font-bold uppercase mb-2">Platform Volume</div>
            <div className="text-4xl font-extrabold text-white">${(stats?.volume || 0).toLocaleString()}</div>
          </div>
        </div>

        <div className="bg-slate-900 rounded-3xl border border-white/10 overflow-hidden">
          <div className="p-6 border-b border-white/10 font-bold text-white">User Management</div>
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-500 text-xs uppercase">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Email</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Joined</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm text-slate-300">
              {users.map(u => (
                <tr key={u.id} className="border-t border-white/5 hover:bg-white/5">
                  <td className="px-6 py-4">#{u.id}</td>
                  <td className="px-6 py-4 font-bold text-white">{u.email}</td>
                  <td className="px-6 py-4">
                    <span className={cn("px-2 py-0.5 rounded text-xs font-bold", u.role === 'admin' ? "bg-purple-500/20 text-purple-400" : "bg-blue-500/20 text-blue-400")}>
                      {u.role.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4">{new Date(u.created_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => handleManageUser(u.id)}
                      className="text-blue-400 hover:underline font-bold"
                    >
                      Manage
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Withdrawal Requests */}
        <div className="bg-slate-900 rounded-3xl border border-white/10 overflow-hidden mt-12">
          <div className="p-6 border-b border-white/10 font-bold text-white flex justify-between items-center">
            <span>Withdrawal Requests</span>
            {withdrawals.filter(w => w.status === 'pending').length > 0 && (
              <span className="bg-rose-500 text-white text-[10px] px-2 py-0.5 rounded-full animate-pulse">
                {withdrawals.filter(w => w.status === 'pending').length} PENDING
              </span>
            )}
          </div>
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-500 text-xs uppercase">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Amount</th>
                <th className="px-6 py-4">Address</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm text-slate-300">
              {withdrawals.map(w => (
                <tr key={w.id} className="border-t border-white/5 hover:bg-white/5">
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{w.email}</div>
                    <div className="text-[10px] text-slate-500">{new Date(w.created_at).toLocaleString()}</div>
                  </td>
                  <td className="px-6 py-4 font-bold text-white">
                    {w.amount.toLocaleString()} {w.currency}
                  </td>
                  <td className="px-6 py-4">
                    <code className="text-[10px] bg-slate-950 p-1 rounded border border-white/5 font-mono break-all max-w-[200px] block">
                      {w.address}
                    </code>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                      w.status === 'pending' ? "bg-amber-500/20 text-amber-500" :
                      w.status === 'approved' ? "bg-emerald-500/20 text-emerald-500" :
                      "bg-rose-500/20 text-rose-500"
                    )}>
                      {w.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {w.status === 'pending' && (
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleApproveWithdrawal(w.id)}
                          className="text-emerald-500 hover:underline font-bold"
                        >
                          Approve
                        </button>
                        <button 
                          onClick={() => handleRejectWithdrawal(w.id)}
                          className="text-rose-500 hover:underline font-bold"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
              {withdrawals.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500 italic">No withdrawal requests found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Support Management */}
        <div className="bg-slate-900 rounded-3xl border border-white/10 overflow-hidden mt-12">
          <div className="p-6 border-b border-white/10 font-bold text-white flex justify-between items-center">
            <span>Customer Support Tickets</span>
            {supportMessages.filter(m => m.status === 'open').length > 0 && (
              <span className="bg-blue-500 text-white text-[10px] px-2 py-0.5 rounded-full animate-pulse">
                {supportMessages.filter(m => m.status === 'open').length} NEW
              </span>
            )}
          </div>
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-slate-500 text-xs uppercase">
              <tr>
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Message</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm text-slate-300">
              {supportMessages.map(m => (
                <tr key={m.id} className="border-t border-white/5 hover:bg-white/5">
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{m.email}</div>
                    <div className="text-[10px] text-slate-500">{new Date(m.created_at).toLocaleString()}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-white mb-1">{m.message}</div>
                    {m.reply && (
                      <div className="text-[10px] text-emerald-400 bg-emerald-400/10 p-2 rounded-lg border border-emerald-400/20">
                        <span className="font-bold uppercase mr-1">Reply:</span> {m.reply}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                      m.status === 'open' ? "bg-blue-500/20 text-blue-400" : "bg-slate-500/20 text-slate-500"
                    )}>
                      {m.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {m.status === 'open' && (
                      <button 
                        onClick={() => setReplyingTo(m)}
                        className="text-blue-400 hover:underline font-bold"
                      >
                        Reply
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {supportMessages.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-slate-500 italic">No support tickets found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reply Modal */}
      <Modal 
        isOpen={!!replyingTo} 
        onClose={() => setReplyingTo(null)} 
        title={`Reply to: ${replyingTo?.email}`}
      >
        <div className="space-y-6">
          <div className="p-4 bg-slate-950 rounded-2xl border border-white/5">
            <div className="text-xs font-bold text-slate-500 uppercase mb-2">User Message</div>
            <div className="text-white text-sm italic">"{replyingTo?.message}"</div>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Your Reply</label>
            <textarea 
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-blue-500 transition-all min-h-[120px]"
              placeholder="Type your response here..."
            />
          </div>
          <button 
            onClick={handleReplySupport}
            disabled={!replyText}
            className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-600/20"
          >
            Send Reply
          </button>
        </div>
      </Modal>

      {/* User Management Modal */}
      <Modal 
        isOpen={isManageOpen} 
        onClose={() => setIsManageOpen(false)} 
        title={`Manage User: ${selectedUser?.email}`}
      >
        {selectedUser && (
          <div className="space-y-8">
            {/* Role Management */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Account Role</label>
              <div className="flex gap-2">
                <button 
                  onClick={() => handleUpdateRole('user')}
                  className={cn("flex-1 py-2 rounded-lg font-bold transition-all", selectedUser.role === 'user' ? "bg-blue-600 text-white" : "bg-slate-950 text-slate-500")}
                >
                  User
                </button>
                <button 
                  onClick={() => handleUpdateRole('admin')}
                  className={cn("flex-1 py-2 rounded-lg font-bold transition-all", selectedUser.role === 'admin' ? "bg-purple-600 text-white" : "bg-slate-950 text-slate-500")}
                >
                  Admin
                </button>
              </div>
            </div>

            {/* Balance Management */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase mb-3">Adjust Balances</label>
              <div className="space-y-3 mb-4">
                {selectedUser.wallets.map((w: any) => (
                  <div key={w.currency} className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-white/5">
                    <span className="font-bold text-white">{w.currency}</span>
                    <span className="font-mono text-blue-400">{(w.balance || 0).toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <select 
                  value={editBalance.currency}
                  onChange={(e) => setEditBalance({ ...editBalance, currency: e.target.value })}
                  className="bg-slate-950 border border-white/10 rounded-xl px-3 text-white outline-none"
                >
                  <option value="USDT">USDT</option>
                  <option value="BTC">BTC</option>
                  <option value="ETH">ETH</option>
                  <option value="SOL">SOL</option>
                </select>
                <input 
                  type="number" 
                  value={editBalance.amount}
                  onChange={(e) => setEditBalance({ ...editBalance, amount: e.target.value })}
                  placeholder="New Balance"
                  className="flex-1 bg-slate-950 border border-white/10 rounded-xl px-4 py-2 text-white outline-none"
                />
                <button 
                  onClick={handleUpdateBalance}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition-all"
                >
                  Set
                </button>
              </div>
            </div>

            {/* Danger Zone */}
            <div className="pt-6 border-t border-white/10">
              <button 
                onClick={handleDeleteUser}
                className="w-full py-3 bg-rose-600/10 hover:bg-rose-600 text-rose-500 hover:text-white border border-rose-500/20 rounded-xl font-bold transition-all"
              >
                Delete Account Permanently
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

const MarketPage = () => {
  const { prices } = useMarketStore();
  
  return (
    <div className="min-h-screen bg-slate-950 pt-24 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-10">
          <h1 className="text-4xl font-extrabold text-white">Market Overview</h1>
          <div className="flex gap-2">
            <span className="px-4 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm font-bold border border-blue-500/30">All Assets</span>
            <span className="px-4 py-1 bg-white/5 text-slate-400 rounded-full text-sm font-bold border border-white/10">Metaverse</span>
            <span className="px-4 py-1 bg-white/5 text-slate-400 rounded-full text-sm font-bold border border-white/10">DeFi</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-white/10 rounded-[2rem] overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-950/50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-8 py-6">Asset</th>
                <th className="px-8 py-6">Price</th>
                <th className="px-8 py-6">24h Change</th>
                <th className="px-8 py-6">Market Cap</th>
                <th className="px-8 py-6">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {Object.entries(prices).map(([pair, price]) => (
                <tr key={pair} className="hover:bg-white/5 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/10">
                        <Zap className="text-white w-6 h-6" />
                      </div>
                      <div>
                        <div className="font-bold text-white text-lg">{pair.split('/')[0]}</div>
                        <div className="text-xs text-slate-500 font-medium">Nexus Network</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="font-mono font-bold text-white text-lg">${(price || 0).toLocaleString()}</div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-1 text-emerald-500 font-bold">
                      <ArrowUpRight className="w-4 h-4" />
                      +3.24%
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="text-slate-300 font-medium">
                      {pair.startsWith('BTC') ? '$2.14 Trillion' : pair.startsWith('ETH') ? '$342.5 Billion' : '$88.2 Billion'}
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <Link to="/trade" className="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold rounded-xl transition-all shadow-lg shadow-blue-600/20">
                      Trade
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// --- App Root ---

export default function App() {
  const { setPrices } = useMarketStore();
  const { token, setAuth, logout } = useAuthStore();
  const navigate = useNavigate();

  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  useEffect(() => {
    const socket = io();
    socket.on('prices', (data) => {
      setPrices(data);
    });

    // Auto-login if token exists
    if (token) {
      fetch('/api/user/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      }).then(res => {
        if (!res.ok) throw new Error('Invalid token');
        return res.json();
      }).then(data => {
        if (data.id) {
          setAuth(data, token);
        } else {
          logout();
        }
      }).catch(() => {
        logout();
      });
    }

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="font-sans selection:bg-blue-500/30">
      <Navbar />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/market" element={<MarketPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/trade" element={<TradePage />} />
        <Route path="/futures" element={<FuturesPage />} />
        <Route path="/wallet" element={<WalletPage />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>

      <AnimatePresence>
        {token && (
          <BottomNav 
            onSupport={() => setIsSupportOpen(true)}
            onTrade={() => navigate('/trade')}
            onNotification={() => setIsNotificationOpen(true)}
            onMy={() => setIsProfileOpen(true)}
          />
        )}
      </AnimatePresence>

      <SupportModal isOpen={isSupportOpen} onClose={() => setIsSupportOpen(false)} />
      <NotificationModal isOpen={isNotificationOpen} onClose={() => setIsNotificationOpen(false)} />
      <ProfileModal isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />
    </div>
  );
}
