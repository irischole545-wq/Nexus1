import { create } from 'zustand';

interface User {
  id: number;
  email: string;
  role: string;
  created_at: string;
  wallets: { currency: string; balance: number; mining_balance: number; mining_profit: number }[];
}

interface AuthState {
  user: User | null;
  token: string | null;
  setAuth: (user: User, token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: localStorage.getItem('token'),
  setAuth: (user, token) => {
    localStorage.setItem('token', token);
    set({ user, token });
  },
  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, token: null });
  },
}));

interface MarketState {
  prices: Record<string, number>;
  setPrices: (prices: Record<string, number>) => void;
}

export const useMarketStore = create<MarketState>((set) => ({
  prices: {},
  setPrices: (prices) => set({ prices }),
}));
